/**
 * @author 杨志恒
 */
package test;
import cn.edu.sdjzu.xg.bysj.dao.SchoolDao;
import cn.edu.sdjzu.xg.bysj.domain.School;
import java.sql.SQLException;

/**
 * 只是一个测试，测试正确性
 * 文件夹其他地方几乎未修改
 */
public class SchoolDaoTest {
    public static void main(String[] args) throws SQLException {
//        //创建School对象
//        School schoolToAdd = new School("管理","02","The best");
//        //由于调用了SchoolDao的无参构造器，暂时将其改为public
//        SchoolDao schoolDao = new SchoolDao();
//        School addSchool = schoolDao.addWithSP(schoolToAdd);
//        System.out.println(addSchool+"\n添加成功");
    }
}
